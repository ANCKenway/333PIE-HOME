"""
Version centralisée pour 333HOME Agent
======================================

Fichier unique pour gestion version.
Importé par agent.py et plugins.
"""

__version__ = "1.0.35"
